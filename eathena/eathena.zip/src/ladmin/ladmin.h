// $Id: ladmin.h,v 1.1.1.1 2004/09/10 17:26:52 MagicalTux Exp $
#ifndef _LADMIN_H_
#define _LADMIN_H_

#define LADMIN_CONF_NAME	"conf/ladmin_athena.conf"
#define PASSWORDENC		3	// A definition is given when making an encryption password correspond.
							// It is 1 at the time of passwordencrypt.
							// It is made into 2 at the time of passwordencrypt2.
							// When it is made 3, it corresponds to both.

#endif
