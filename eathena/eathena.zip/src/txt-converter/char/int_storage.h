#ifndef _INT_STORAGE_H_
#define _INT_STORAGE_H_

int inter_storage_init();
int inter_storage_save();

int inter_storage_parse_frommap(int fd);

//extern char storage_txt[256];

#endif
